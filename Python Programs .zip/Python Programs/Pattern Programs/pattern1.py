for i in range(1,4,1):
                        for j in range(1,i+1,1):
                                                    print j,
                        for j in range(i,1,-1):
                                                    print j,
                        print "\n"
                        
                           



                                                 
                                    
                                                   
                     
