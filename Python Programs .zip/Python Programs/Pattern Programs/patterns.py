for i in range(1,7):
                     for j in range(1,7-i+2):
                                              print " ",

                     for j in range(1,2*i):
                                              print "*",

                     print "\n"


         
                                              
                                          
     
