a=[5,3,7,2,8,7,9,10]

def max(x):
            max=-1;

            for i in x:
                        if(max<i):
                                   max=i
            print "The greatest number is:",max            

max(a)
