n=(raw_input("enter any number"))
b=len(n)
print b
