a=[5,3,7,2,8,7,9,10]

def avg(x):
            sum=0;

            for i in x:
                        sum=sum+i;

            print "Sum:",sum            

avg(a)
                    
