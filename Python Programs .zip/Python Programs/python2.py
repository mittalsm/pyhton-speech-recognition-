for i in range(0,7):
                     for j in range(1,i):
                                          print "*",
                     print "\n"
        
